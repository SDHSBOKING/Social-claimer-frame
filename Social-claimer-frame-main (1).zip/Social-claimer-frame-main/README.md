```
npm install
npm run dev
```

Head to http://localhost:5173/api